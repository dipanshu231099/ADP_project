to run on your pc do the following steps:
1. Open the php files ('result.php' and 'gethint.php) and change the username and password according to your mysql req.
2. Use the project.sql dumpfile to restore the db project in your mysql;
3. If you get an error in dumping try creating the db "project" in mysql first.

